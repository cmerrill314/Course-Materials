To compile this program, use:

g++ -std=c++11 nn.cpp -o n

Then run using:

./n fileName.txt

where fileName.txt is the name of the text file you wish to test