/*********************************************************************
** This is the header file for the determinant function, it includes
** the function declarator.
*********************************************************************/

#ifndef DETERMINANT_HPP //include guard
#define DETERMINANT_HPP

//function declarator
int determinant(int** mtrx, int size);

#endif