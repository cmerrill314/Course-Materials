/*********************************************************************
** This is the header file for the readMatrix function, it includes 
** the function declarator. 
*********************************************************************/

#ifndef READMATRIX_HPP //include guard
#define READMATRIX_HPP

//function declarator
void readMatrix(int** mtrx, int size);

#endif